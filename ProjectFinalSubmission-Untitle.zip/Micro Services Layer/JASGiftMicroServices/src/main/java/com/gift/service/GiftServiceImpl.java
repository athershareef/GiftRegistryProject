package com.gift.service;

import org.springframework.stereotype.Service;

/**
 * The Class GiftServiceImpl.
 */
@Service("giftService")
public class GiftServiceImpl implements IGiftService {

}
