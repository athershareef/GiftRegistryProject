package com.gift.service;

/**
 * The Interface IGiftService.
 */
public interface IGiftService {

}
