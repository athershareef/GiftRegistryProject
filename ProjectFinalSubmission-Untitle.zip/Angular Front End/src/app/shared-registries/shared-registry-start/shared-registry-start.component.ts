import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-shared-registry-start',
  templateUrl: './shared-registry-start.component.html',
  styleUrls: ['./shared-registry-start.component.css']
})
export class SharedRegistryStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
