import {Item} from './item';
import {User} from './user';

export class RegistryItem {
  public registry: number;
  public item: Item;
  public giftUser: User;
}
