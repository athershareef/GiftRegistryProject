import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-registry-start',
  templateUrl: './registry-start.component.html',
  styleUrls: ['./registry-start.component.css']
})
export class RegistryStartComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {

  }

}
