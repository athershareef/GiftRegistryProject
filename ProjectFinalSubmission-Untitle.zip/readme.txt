Front-End Module: Please import the module contained in the "Angular Front End" folder inside the "ProjectFinalSubmission-Untitle.zip" in the IDE of your choice(WebStorm Preferred). Go to the 'view' tab and select 'terminal', Now inside the terminal type the command "npm start" to run the project's front-end module.
Note: Please make sure you do "npm install package.json" before you run the module to install the dependencies.

Web-services Module: Please import the module contained in the "Service Layer" folder inside the "ProjectFinalSubmission-Untitle.zip" in the IDE of your choice(Eclipse Preferred). Right click on the imported project and select "run as springboot app".

Micro-services Module: Please import the module contained in the "Micro Service Layer" folder inside the "ProjectFinalSubmission-Untitle.zip" in the IDE of your choice(Eclipse Preferred). Right click on the imported project and select "run as springboot app".


If the steps above are done correctly then we have 3 separate servers running on the following addresses:

Front-End: https://localhost:4200/
Web-services: https://localhost:8443/
Micro-services: https://localhost:9090/
