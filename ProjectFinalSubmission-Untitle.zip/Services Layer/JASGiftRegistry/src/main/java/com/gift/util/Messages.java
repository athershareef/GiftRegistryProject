package com.gift.util;

/**
 * The Class Messages.
 */
public final class Messages {

	/** The Constant MAX_YEAR. */
	public static final int MAX_YEAR = 2050;

}
